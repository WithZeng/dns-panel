package messageevent

const (
	Offline = "Offline"
	Online  = "Online"
	Expire  = "Expire"
	Renew   = "Renew"
	Login   = "Login"
	Alert   = "Alert"
	Traffic = "Traffic"
)
