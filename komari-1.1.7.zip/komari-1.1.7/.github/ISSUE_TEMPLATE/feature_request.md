---
name: Feature Request
about: Suggest an idea for this project
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

### 建议的解决方案/Proposed Solution
简明扼要地描述你希望发生的事情。
A clear and concise description of what you want to happen.
