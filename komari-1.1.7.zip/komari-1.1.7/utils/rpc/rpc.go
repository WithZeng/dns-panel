package rpc

const (
	RPC_VERSION = "2.0"
)
