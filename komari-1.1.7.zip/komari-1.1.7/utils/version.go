package utils

var (
	CurrentVersion = "0.0.1"
	VersionHash    = "unknown"
)
